### Bug Reports
You MUST post a recreation or else your issue will be CLOSED without explanation.
Instructions: https://fullcalendar.io/reporting-bugs

### Feature Requests
Search the issue tracker for an existing ticket before creating a new one.
Instructions: https://fullcalendar.io/requesting-features

### Is your bug/feature applicable to the core project, without Angular?
If so, use the main tracker: https://github.com/fullcalendar/fullcalendar/issues

(Please erase the above text and begin typing. Thanks!)
