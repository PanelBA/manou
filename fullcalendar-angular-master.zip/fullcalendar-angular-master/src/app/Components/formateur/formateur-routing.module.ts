import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListformateurComponent } from './listformateur/listformateur.component';
import { CalendrierformateurComponent } from './calendrierformateur/calendrierformateur.component';
import { EmploijourComponent } from './emploijour/emploijour.component';

const routes: Routes = [
               { path: 'formateur/lister', component: ListformateurComponent },
               { path: 'formateur/calendrier/:id', component:CalendrierformateurComponent  },


                       ];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FormateurRoutingModule { }
