import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormateurRoutingModule } from './formateur-routing.module';
import { ListformateurComponent } from './listformateur/listformateur.component';
import { CalendrierformateurComponent } from './calendrierformateur/calendrierformateur.component';
import { FullCalendarModule } from '@fullcalendar/angular';
import { HttpClientModule } from '@angular/common/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { EmploijourComponent } from './emploijour/emploijour.component';
import { MatDialogModule } from '@angular/material/dialog';

@NgModule({
  declarations: [ListformateurComponent, CalendrierformateurComponent, EmploijourComponent],
  imports: [
    CommonModule,
    FormateurRoutingModule,
 FullCalendarModule ,HttpClientModule ,NgbModule ,MatDialogModule
  ] ,    entryComponents: [EmploijourComponent]

})
export class FormateurModule { }
