import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmploijourComponent } from './emploijour.component';

describe('EmploijourComponent', () => {
  let component: EmploijourComponent;
  let fixture: ComponentFixture<EmploijourComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmploijourComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmploijourComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
