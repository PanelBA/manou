import {Inject,  Component, OnInit } from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from "@angular/material/dialog";
import { CalendrierformateurComponent } from '../calendrierformateur/calendrierformateur.component';
import {Formateur} from '../../../Model/Formateur';
import {FormateurService} from '../../../Service/formateur.service';
@Component({
  selector: 'app-emploijour',
  templateUrl: './emploijour.component.html',
  styleUrls: ['./emploijour.component.scss']
})
export class EmploijourComponent implements OnInit {
 date : string ;
id :number ;
formateur :Formateur =new Formateur() ;
  constructor( private formateurservice :FormateurService , private dialogRef: MatDialogRef<CalendrierformateurComponent>,
        @Inject(MAT_DIALOG_DATA) data ) {

this.date =data.date ;
this.id =data.id ;
            this.formateurservice.get(this.id)
      .subscribe(data => {
        console.log(data)
        this.formateur = data;
      }, error => console.log(error));

  }

  ngOnInit(): void {
  }

}
