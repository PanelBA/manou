import { Component, OnInit , ViewChild  } from '@angular/core';
import { Calendar } from '@fullcalendar/core'; // include this line
import { CalendarOptions } from '@fullcalendar/core';
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction';
import { FullCalendarComponent } from '@fullcalendar/angular';
import { Router, ActivatedRoute } from '@angular/router';
import { ListformateurComponent } from '../listformateur/listformateur.component';
import {Formateur} from '../../../Model/Formateur';
import {FormateurService} from '../../../Service/formateur.service';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {MatDialog, MatDialogConfig} from "@angular/material/dialog";
import { EmploijourComponent } from '../emploijour/emploijour.component';

@Component({
  selector: 'app-calendrierformateur',
  templateUrl: './calendrierformateur.component.html',
  styleUrls: ['./calendrierformateur.component.scss']
})
export class CalendrierformateurComponent implements OnInit {
    sub;
    id ;
   formateur : Formateur ;
constructor( private dialog: MatDialog , private modalService: NgbModal ,config: NgbModalConfig  , private _Activatedroute:ActivatedRoute, private router: Router ,private formateurService: FormateurService) {
    const name = Calendar.name; // add this line in your constructor
    config.backdrop = 'static';
    config.keyboard = false;

  }

  calendarOptions: CalendarOptions;
  eventsModel: any;
  @ViewChild('fullcalendar') fullcalendar: FullCalendarComponent;

  ngOnInit() {

          this.sub=this._Activatedroute.paramMap.subscribe(params => {
         console.log(params);
                   this.id = params.get('id');
              this.formateurService.get(this.id)
      .subscribe(data => {
        console.log(data)
        this.formateur = data;
      }, error => console.log(error));

      });



    this.calendarOptions = {
      plugins: [dayGridPlugin, interactionPlugin],
      editable: true,
      customButtons: {
        myCustomButton: {
          text: 'custom!',
          click: function () {
            alert('clicked the custom button!');
          }
        }
      },
      headerToolbar: {
        left: 'prev,next today myCustomButton',
        center: 'title',
        right: 'dayGridMonth'
      },
      dateClick: this.handleDateClick.bind(this),
      eventClick: this.handleEventClick.bind(this),
      eventDragStop: this.handleEventDragStop.bind(this)
    };


  }

  handleDateClick(arg) {
    console.log(arg);
  const dialogConfig = new MatDialogConfig();

        dialogConfig.disableClose = false;
        dialogConfig.autoFocus = true;
   dialogConfig.data = {
        id: this.id,
        date: arg.dateStr
    };

       console.log("ahla rihab "+arg.dateStr);
              this.dialog.open(EmploijourComponent,dialogConfig);


  }

  handleEventClick(arg)  {
    console.log(arg);
  console.log("ahla manel ");
  }

  handleEventDragStop(arg) {
    console.log(arg);
  }

  updateHeader() {
    this.calendarOptions.headerToolbar = {
      left: 'prev,next myCustomButton',
      center: 'title',
      right: ''
    };
  }

  updateEvents() {
    const nowDate = new Date();
    const yearMonth = nowDate.getUTCFullYear() + '-' + (nowDate.getUTCMonth() + 1);

    this.calendarOptions.events = [{
      title: 'Updaten Event',
      start: yearMonth + '-08',
      end: yearMonth + '-10'
    }];
  }


}

