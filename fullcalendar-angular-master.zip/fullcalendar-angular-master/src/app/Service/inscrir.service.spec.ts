import { TestBed } from '@angular/core/testing';

import { InscrirService } from './inscrir.service';

describe('InscrirService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: InscrirService = TestBed.get(InscrirService);
    expect(service).toBeTruthy();
  });
});
