import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
import {Seance} from '../Model/Seance';
@Injectable({
  providedIn: 'root'
})
export class SeanceService {
constructor(private httpClient: HttpClient) { }

private url = Config.BASE_URL + '/Seance';
private urld = this.url + '/products';
private urlseance = this.url + '/seancebyidsession';
private urldsession = this.url + '/productssession';
  createProduct(product: Seance, idCategory: number,id : number): Observable<object> {
    return this.httpClient.post(`${this.urld}/${idCategory}/${id}`, product);
  }
    createpr(product: Seance, idCategory: number): Observable<object> {
    return this.httpClient.put(`${this.urldsession}/${idCategory}`, product);
  }
   public getseance(id: number): Observable<any> {
    return this.httpClient.get(`${this.urlseance }/${id}`);
  }
  public  getAll(): Observable<Seance[]> {
    return this.httpClient.get<Seance[]>(this.url+'/get');
  }

}
