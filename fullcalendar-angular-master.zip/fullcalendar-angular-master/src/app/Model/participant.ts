import{Session } from './session' ;

import{Utilisateur } from './utilisateur' ;
export class Participant  extends  Utilisateur {
    niveauEtude : String;
    sessions :Session[];
}
