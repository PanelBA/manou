
import { Promotion } from './promotion';
import { Formation } from './formation';

export class Remise {
prixreduit :number ;
promotion :Promotion ;
formation :Formation ;
datedebut :string ;
datefin :string ;
}
