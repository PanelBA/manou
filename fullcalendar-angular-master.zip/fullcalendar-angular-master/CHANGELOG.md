
5.3.1 (2020-09-03)
------------------
- add Angular 10 support


4.4.1 (2020-02-12)
------------------
- fixed wrong @fullcalendar/core dependency version num


4.3.2 (2020-02-11)
------------------
- compatible with angular 8 (#209)
- navLinks throws Cannot read property 'emit' of undefined (#229, #241)


4.3.1 (2019-08-10)
------------------
- had references to wrong version of @fullcalendar/core


4.3.0 (2019-08-09)
------------------
- fix ngOnDestroy undefined calendar (#212)


4.2.1 (2019-06-04)
------------------
- fixed bug with event/resource-fetching *functions* not working
- removed `deep-copy` as a dependency


4.2.0 (2019-06-02)
------------------
- added missing properties (#197)
- responds to changes nested within input data structures
  when `deepChangeDetection` is enabled (#171)
- added two small dependencies:
  - `fast-deep-equal`
  - `deep-copy`


4.1.1 (2019-04-24)
------------------
fixes not accepting `googleCalendarApiKey` (#188)


4.1.0 (2019-03-19)
------------------
First official release. Also fixed #175.
